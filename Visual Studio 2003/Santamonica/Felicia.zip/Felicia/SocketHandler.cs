using System;

namespace Navipro.SantaMonica.Felicia
{
	/// <summary>
	/// Summary description for SocketHandler.
	/// </summary>
	public class SocketHandler
	{
		public SocketHandler()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
