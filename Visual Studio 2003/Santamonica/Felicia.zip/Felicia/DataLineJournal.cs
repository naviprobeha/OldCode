using System;
using System.Data;
using System.Data.SqlServerCe;
using System.Collections;
using System.Xml;

namespace Navipro.SantaMonica.Felicia
{
	/// <summary>
	/// Summary description for DataColor.
	/// </summary>
	public class DataLineJournal
	{
		public int entryNo;
		public string organizationNo;
		public DateTime shipDate;
		public string agentCode;
		public int status;
		public string departureFactoryCode;
		public string arrivalFactoryCode;

		public float calculatedDistance;
		public float measuredDistance;
		public float reportedDistance;

		public float reportedDistanceSingle;
		public float reportedDistanceTrailer;

		private string updateMethod;
		private SmartDatabase smartDatabase;

		public DataLineJournal(SmartDatabase smartDatabase, int entryNo)
		{
			//
			// TODO: Add constructor logic here
			//

			this.smartDatabase = smartDatabase;
			this.entryNo = entryNo;
			getFromDb();
		}


		public DataLineJournal(DataSet dataset, SmartDatabase smartDatabase)
		{
			this.smartDatabase = smartDatabase;
			fromDataSet(dataset);				
			commit();
		}



		public void fromDataSet(DataSet dataset)
		{
			entryNo = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(0).ToString());
			organizationNo = dataset.Tables[0].Rows[0].ItemArray.GetValue(1).ToString();
			shipDate = DateTime.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(2).ToString());
			agentCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(3).ToString();
			status = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(4).ToString());
			departureFactoryCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(5).ToString();
			arrivalFactoryCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(6).ToString();
			calculatedDistance = float.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(9).ToString());

		}


		public void commit()
		{
			SqlCeDataReader dataReader = smartDatabase.query("SELECT * FROM lineJournal WHERE entryNo = '"+entryNo+"'");

			if (dataReader.Read())
			{
				if ((updateMethod != null) && (updateMethod.Equals("D")))
				{
					smartDatabase.nonQuery("DELETE FROM lineJournal WHERE entryNo = '"+entryNo+"'");
					smartDatabase.nonQuery("DELETE FROM lineOrder WHERE lineJournalEntryNo = '"+entryNo+"'");
				}
				else
				{

					try
					{
						smartDatabase.nonQuery("UPDATE lineJournal SET entryNo = '"+entryNo.ToString()+"', organizationNo = '"+organizationNo.ToString()+"', shipDate = '"+shipDate.ToString("yyyy-MM-dd")+"', agentCode = '"+agentCode+"', status = '"+status+"', departureFactoryCode = '"+departureFactoryCode+"', arrivalFactoryCode = '"+arrivalFactoryCode+"', calculatedDistance = '"+this.calculatedDistance+"', measuredDistance = '"+this.measuredDistance+"', reportedDistance = '"+this.reportedDistance+"', reportedDistanceSingle = '"+reportedDistanceSingle+"', reportedDistanceTrailer = '"+reportedDistanceTrailer+"' WHERE entryNo = '"+entryNo+"'");
					}
					catch (SqlCeException e) 
					{
						smartDatabase.ShowErrors(e);
					}
				}
			}
			else
			{
				if ((updateMethod == null) || (!updateMethod.Equals("D")))
				{
					try
					{
						smartDatabase.nonQuery("INSERT INTO lineJournal (entryNo, organizationNo, shipDate, agentCode, status, departureFactoryCode, arrivalFactoryCode, calculatedDistance, measuredDistance, reportedDistance, reportedDistanceSingle, reportedDistanceTrailer) VALUES ('"+entryNo.ToString()+"','"+organizationNo+"','"+shipDate.ToString("yyyy-MM-dd")+"','"+agentCode+"', '"+status+"', '"+departureFactoryCode+"', '"+arrivalFactoryCode+"', '"+calculatedDistance+"', '"+measuredDistance+"', '"+reportedDistance+"', '"+reportedDistanceSingle+"', '"+reportedDistanceTrailer+"')");
					
					}
					catch (SqlCeException e) 
					{
						smartDatabase.ShowErrors(e);
					}
				}
			}
			dataReader.Dispose();	
		}
		

		public bool getFromDb()
		{
		
			SqlCeDataReader dataReader = smartDatabase.query("SELECT entryNo, organizationNo, shipDate, agentCode, status, departureFactoryCode, arrivalFactoryCode, calculatedDistance, measuredDistance, reportedDistance, reportedDistanceSingle, reportedDistanceTrailer FROM lineJournal WHERE entryNo = '"+entryNo+"'");

			if (dataReader.Read())
			{
				try
				{
					this.entryNo = dataReader.GetInt32(0);
					this.organizationNo = dataReader.GetValue(1).ToString();
					this.shipDate = dataReader.GetDateTime(2);
					this.agentCode = dataReader.GetValue(3).ToString();
					this.status = dataReader.GetInt32(4);
					this.departureFactoryCode = dataReader.GetValue(5).ToString();
					this.arrivalFactoryCode = dataReader.GetValue(6).ToString();
					this.calculatedDistance = float.Parse(dataReader.GetValue(7).ToString());
					this.measuredDistance = float.Parse(dataReader.GetValue(8).ToString());
					this.reportedDistance = float.Parse(dataReader.GetValue(9).ToString());
					this.reportedDistanceSingle = float.Parse(dataReader.GetValue(10).ToString());
					this.reportedDistanceTrailer = float.Parse(dataReader.GetValue(11).ToString());
					
					dataReader.Dispose();
					return true;
				}
				catch (SqlCeException e) 
				{
					smartDatabase.ShowErrors(e);
				}
			}
			dataReader.Dispose();
			return false;
			
		}

		public void delete()
		{
			this.updateMethod = "D";
			commit();
		}

		public int countLineOrders()
		{
			int noOfOrders = 0;

			SqlCeDataReader dataReader = smartDatabase.query("SELECT COUNT(*) FROM lineOrder WHERE lineJournalEntryNo = '"+entryNo+"'");

			if (dataReader.Read())
			{
				noOfOrders = dataReader.GetInt32(0);
			}

			dataReader.Close();

			return noOfOrders;
		}

		public ArrayList getContainerList()
		{
			ArrayList containerList = new ArrayList();

			SqlCeDataReader dataReader = smartDatabase.query("SELECT c.containerNo FROM lineOrder o, lineOrderContainer c, containerLoad l WHERE o.lineJournalEntryNo = '"+entryNo+"' AND c.lineOrderEntryNo = o.entryNo AND l.containerNo = c.containerNo");
			while (dataReader.Read())
			{
				containerList.Add(dataReader.GetValue(0).ToString());

			}

			dataReader.Close();

			return containerList;

		}

		public ArrayList getLoadedLineOrders()
		{
			ArrayList lineOrderList = new ArrayList();

			SqlCeDataReader dataReader = smartDatabase.query("SELECT entryNo FROM lineOrder WHERE lineJournalEntryNo = '"+entryNo+"' AND status = 7");
			while (dataReader.Read())
			{
				lineOrderList.Add(dataReader.GetValue(0).ToString());

			}

			dataReader.Close();

			return lineOrderList;

		}
	}
}
