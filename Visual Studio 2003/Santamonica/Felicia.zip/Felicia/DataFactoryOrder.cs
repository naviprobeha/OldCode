using System;
using System.Data;
using System.Data.SqlServerCe;
using System.Xml;

namespace Navipro.SantaMonica.Felicia
{
	/// <summary>
	/// Summary description for DataColor.
	/// </summary>
	public class DataFactoryOrder
	{
		public int entryNo;
		public string organizationNo;
		public DateTime shipDate;
		public int factoryType;
		public string factoryNo;
		public string factoryName;
		public string factoryAddress;
		public string factoryAddress2;
		public string factoryPostCode;
		public string factoryCity;
		public string factoryCountryCode;
		public string factoryPhoneNo;
		public string consumerNo;
		public string consumerName;
		public string consumerAddress;
		public string consumerAddress2;
		public string consumerPostCode;
		public string consumerCity;
		public string consumerCountryCode;
		public string consumerPhoneNo;
		public string categoryCode;
		public string categoryDescription;
		public float quantity;
		public float realQuantity;
		public int factoryPositionX;
		public int factoryPositionY;
		public int consumerPositionX;
		public int consumerPositionY;
		public int type;
		public int status;
		public DateTime closedDateTime;
		public DateTime shipTime;
		public DateTime creationDate;
		public DateTime arrivalDateTime;
		public string agentCode;
		public float consumerLevel;

		public int loadDuration;
		public int loadWaitDuration;
		public int dropDuration;
		public int dropWaitDuration;

		public float phValueShipping;

		public int loadReasonValue;
		public string loadReasonText;
		public int dropReasonValue;
		public string dropReasonText;

		private string updateMethod;
		private SmartDatabase smartDatabase;

		public DataFactoryOrder(SmartDatabase smartDatabase, int entryNo)
		{
			//
			// TODO: Add constructor logic here
			//

			this.smartDatabase = smartDatabase;
			this.entryNo = entryNo;
			getFromDb();
		}


		public DataFactoryOrder(DataSet dataset, SmartDatabase smartDatabase)
		{
			this.smartDatabase = smartDatabase;
			fromDataSet(dataset);				
			commit();
		}



		public void fromDataSet(DataSet dataset)
		{
			entryNo = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(0).ToString());
			organizationNo = dataset.Tables[0].Rows[0].ItemArray.GetValue(1).ToString();
			shipDate = DateTime.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(2).ToString());
			factoryNo = dataset.Tables[0].Rows[0].ItemArray.GetValue(3).ToString();
			factoryName = dataset.Tables[0].Rows[0].ItemArray.GetValue(4).ToString();
			factoryAddress = dataset.Tables[0].Rows[0].ItemArray.GetValue(5).ToString();
			factoryAddress2 = dataset.Tables[0].Rows[0].ItemArray.GetValue(6).ToString();
			factoryPostCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(7).ToString();
			factoryCity = dataset.Tables[0].Rows[0].ItemArray.GetValue(8).ToString();
			factoryCountryCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(9).ToString();
			factoryPhoneNo = dataset.Tables[0].Rows[0].ItemArray.GetValue(10).ToString();
			consumerNo = dataset.Tables[0].Rows[0].ItemArray.GetValue(11).ToString();
			consumerName = dataset.Tables[0].Rows[0].ItemArray.GetValue(12).ToString();
			consumerAddress = dataset.Tables[0].Rows[0].ItemArray.GetValue(13).ToString();
			consumerAddress2 = dataset.Tables[0].Rows[0].ItemArray.GetValue(14).ToString();
			consumerPostCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(15).ToString();
			consumerCity = dataset.Tables[0].Rows[0].ItemArray.GetValue(16).ToString();
			consumerCountryCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(17).ToString();
			consumerPhoneNo = dataset.Tables[0].Rows[0].ItemArray.GetValue(18).ToString();
			categoryCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(19).ToString();
			categoryDescription = dataset.Tables[0].Rows[0].ItemArray.GetValue(20).ToString();
			quantity = float.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(21).ToString());
            factoryPositionX = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(22).ToString());
			factoryPositionY = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(23).ToString());
			consumerPositionX = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(24).ToString());
			consumerPositionY = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(25).ToString());		
			type = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(26).ToString());
			status = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(27).ToString());
			
			DateTime closedDate = DateTime.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(28).ToString());
			DateTime closedTime = DateTime.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(29).ToString());
			this.closedDateTime = DateTime.Parse(closedDate.ToString("yyyy-MM-dd")+" "+closedTime.ToString("HH:mm:ss"));

			shipTime = DateTime.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(30).ToString());
			creationDate = DateTime.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(31).ToString());


			agentCode = dataset.Tables[0].Rows[0].ItemArray.GetValue(34).ToString();

			factoryType = int.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(35).ToString());

			DateTime arrivalDate = DateTime.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(36).ToString());
			DateTime arrivalTime = DateTime.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(37).ToString());
			this.arrivalDateTime = DateTime.Parse(arrivalDate.ToString("yyyy-MM-dd")+" "+arrivalTime.ToString("HH:mm:ss"));


			realQuantity = float.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(39).ToString());
			
			phValueShipping = float.Parse(dataset.Tables[0].Rows[0].ItemArray.GetValue(46).ToString());

		}


		public void commit()
		{

			SqlCeDataReader dataReader = smartDatabase.query("SELECT * FROM factoryOrder WHERE entryNo = '"+entryNo+"'");

			if (dataReader.Read())
			{
				if ((updateMethod != null) && (updateMethod.Equals("D")))
				{
					smartDatabase.nonQuery("DELETE FROM factoryOrder WHERE entryNo = '"+entryNo+"'");
				}
				else
				{

					try
					{
						smartDatabase.nonQuery("UPDATE factoryOrder SET entryNo = '"+entryNo.ToString()+"', organizationNo = '"+organizationNo.ToString()+"', shipDate = '"+shipDate.ToString("yyyy-MM-dd")+"', factoryType = '"+factoryType+"', factoryNo = '"+factoryNo+"', factoryName = '"+factoryName+"', factoryAddress = '"+this.factoryAddress+"', factoryAddress2 = '"+this.factoryAddress2+"', factoryPostCode = '"+this.factoryPostCode+"', factoryCity = '"+this.factoryCity+"', factoryCountryCode = '"+this.factoryCountryCode+"', factoryPhoneNo = '"+this.factoryPhoneNo+"', consumerNo = '"+this.consumerNo+"', consumerName = '"+this.consumerName+"', consumerAddress = '"+this.consumerAddress+"', consumerAddress2 = '"+this.consumerAddress2+"', consumerPostCode = '"+this.consumerPostCode+"', consumerCity = '"+this.consumerCity+"', consumerCountryCode = '"+this.consumerCountryCode+"', consumerPhoneNo = '"+this.consumerPhoneNo+"', categoryCode = '"+this.categoryCode+"', categoryDescription = '"+this.categoryDescription+"', quantity = '"+quantity+"', realQuantity = '"+realQuantity+"', factoryPositionX = '"+factoryPositionX+"', factoryPositionY = '"+factoryPositionY+"', consumerPositionX = '"+consumerPositionX+"', consumerPositionY = '"+this.consumerPositionY+"', type = '"+type+"', status = '"+status+"', closedDateTime = '"+this.closedDateTime.ToString("yyyy-MM-dd HH:mm.ss")+"', shipTime = '"+shipTime.ToString("yyyy-MM-dd HH:mm:ss")+"', creationDate = '"+this.creationDate.ToString("yyyy-MM-dd")+"', arrivalDateTime = '"+this.arrivalDateTime.ToString("yyyy-MM-dd HH:mm:ss")+"', agentCode = '"+this.agentCode+"', consumerLevel = '"+consumerLevel+"', loadDuration = '"+loadDuration+"', loadWaitDuration = '"+loadWaitDuration+"', dropDuration = '"+dropDuration+"', dropWaitDuration = '"+dropWaitDuration+"', phValueShipping = '"+phValueShipping+"', loadReasonValue = '"+loadReasonValue+"', loadReasonText = '"+loadReasonText+"', dropReasonValue = '"+dropReasonValue+"', dropReasonText = '"+dropReasonText+"' WHERE entryNo = '"+entryNo+"'");
					}
					catch (SqlCeException e) 
					{
						smartDatabase.ShowErrors(e);
					}
				}
			}
			else
			{
				if ((updateMethod == null) || (!updateMethod.Equals("D")))
				{
					try
					{
						smartDatabase.nonQuery("INSERT INTO factoryOrder (entryNo, organizationNo, shipDate, factoryType, factoryNo, factoryName, factoryAddress, factoryAddress2, factoryPostCode, factoryCity, factoryCountryCode, factoryPhoneNo, consumerNo, consumerName, consumerAddress, consumerAddress2, consumerPostCode, consumerCity, consumerCountryCode, consumerPhoneNo, categoryCode, categoryDescription, quantity, realQuantity, factoryPositionX, factoryPositionY, consumerPositionX, consumerPositionY, type, status, closedDateTime, shipTime, creationDate, arrivalDateTime, agentCode, consumerLevel, loadDuration, loadWaitDuration, dropDuration, dropWaitDuration, phValueShipping, loadReasonValue, loadReasonText, dropReasonValue, dropReasonText) VALUES ('"+entryNo.ToString()+"','"+organizationNo+"','"+shipDate.ToString("yyyy-MM-dd")+"','"+factoryType+"','"+factoryNo+"', '"+factoryName+"', '"+factoryAddress+"', '"+factoryAddress2+"', '"+factoryPostCode+"', '"+factoryCity+"', '"+this.factoryCountryCode+"', '"+factoryPhoneNo+"', '"+consumerNo+"', '"+consumerName+"', '"+consumerAddress+"', '"+consumerAddress2+"', '"+consumerPostCode+"', '"+consumerCity+"', '"+consumerCountryCode+"', '"+consumerPhoneNo+"', '"+categoryCode+"', '"+categoryDescription+"', '"+quantity+"', '"+realQuantity+"', '"+factoryPositionX+"', '"+factoryPositionY+"', '"+consumerPositionX+"', '"+consumerPositionY+"', '"+type+"', '"+status+"', '"+closedDateTime.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+shipTime.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+creationDate.ToString("yyyy-MM-dd")+"', '"+arrivalDateTime.ToString("yyyy-MM-dd HH:mm:ss")+"', '"+agentCode+"', '"+consumerLevel+"', '"+loadDuration+"', '"+loadWaitDuration+"', '"+dropDuration+"', '"+dropWaitDuration+"', '"+phValueShipping+"', '"+loadReasonValue+"', '"+loadReasonText+"', '"+dropReasonValue+"', '"+dropReasonText+"')");
					
					}
					catch (SqlCeException e) 
					{
						smartDatabase.ShowErrors(e);
					}
				}
			}
			dataReader.Dispose();	
		}
		

		public bool getFromDb()
		{
		
			SqlCeDataReader dataReader = smartDatabase.query("SELECT entryNo, organizationNo, shipDate, factoryType, factoryNo, factoryName, factoryAddress, factoryAddress2, factoryPostCode, factoryCity, factoryCountryCode, factoryPhoneNo, consumerNo, consumerName, consumerAddress, consumerAddress2, consumerPostCode, consumerCity, consumerCountryCode, consumerPhoneNo, categoryCode, categoryDescription, quantity, realQuantity, factoryPositionX, factoryPositionY, consumerPositionX, consumerPositionY, type, status, closedDateTime, shipTime, creationDate, arrivalDateTime, agentCode, consumerLevel, loadDuration, loadWaitDuration, dropDuration, dropWaitDuration, phValueShipping, loadReasonValue, loadReasonText, dropReasonValue, dropReasonText FROM factoryOrder WHERE entryNo = '"+entryNo+"'");

			if (dataReader.Read())
			{
				try
				{
					this.entryNo = dataReader.GetInt32(0);
					this.organizationNo = dataReader.GetValue(1).ToString();
					this.shipDate = dataReader.GetDateTime(2);
					this.factoryType = dataReader.GetInt32(3);
					this.factoryNo = dataReader.GetValue(4).ToString();
					this.factoryName = dataReader.GetValue(5).ToString();
					this.factoryAddress = dataReader.GetValue(6).ToString();
					this.factoryAddress2 = dataReader.GetValue(7).ToString();
					this.factoryPostCode = dataReader.GetValue(8).ToString();
					this.factoryCity = dataReader.GetValue(9).ToString();
					this.factoryCountryCode = dataReader.GetValue(10).ToString();
					this.factoryPhoneNo = dataReader.GetValue(11).ToString();
					this.consumerNo = dataReader.GetValue(12).ToString();
					this.consumerName = dataReader.GetValue(13).ToString();
					this.consumerAddress = dataReader.GetValue(14).ToString();
					this.consumerAddress2 = dataReader.GetValue(15).ToString();
					this.consumerPostCode = dataReader.GetValue(16).ToString();
					this.consumerCity = dataReader.GetValue(17).ToString();
					this.consumerCountryCode = dataReader.GetValue(18).ToString();
					this.consumerPhoneNo = dataReader.GetValue(19).ToString();
					this.categoryCode = dataReader.GetValue(20).ToString();
					this.categoryDescription = dataReader.GetValue(21).ToString();
					this.quantity = dataReader.GetFloat(22);
					this.realQuantity = dataReader.GetFloat(23);
					this.factoryPositionX = dataReader.GetInt32(24);
					this.factoryPositionY = dataReader.GetInt32(25);
					this.consumerPositionX = dataReader.GetInt32(26);
					this.consumerPositionY = dataReader.GetInt32(27);
					this.type = dataReader.GetInt32(28);
					this.status = dataReader.GetInt32(29);
					this.closedDateTime = dataReader.GetDateTime(30);
                    this.shipTime = dataReader.GetDateTime(31);
					this.creationDate = dataReader.GetDateTime(32);
					this.arrivalDateTime = dataReader.GetDateTime(33);
					this.agentCode = dataReader.GetValue(34).ToString();
					this.consumerLevel = dataReader.GetFloat(35);
					this.loadDuration = dataReader.GetInt32(36);
					this.loadWaitDuration = dataReader.GetInt32(37);
					this.dropDuration = dataReader.GetInt32(38);
					this.dropWaitDuration = dataReader.GetInt32(39);
					this.phValueShipping = dataReader.GetFloat(40);

					this.loadReasonValue = dataReader.GetInt32(41);
					this.loadReasonText = dataReader.GetValue(42).ToString();
					this.dropReasonValue = dataReader.GetInt32(43);
					this.dropReasonText = dataReader.GetValue(44).ToString();

					dataReader.Dispose();
					return true;
				}
				catch (SqlCeException e) 
				{
					smartDatabase.ShowErrors(e);
				}
			}
			dataReader.Dispose();
			return false;
			
		}

		public void delete()
		{
			this.updateMethod = "D";
			commit();
		}

		public string getStatus()
		{
			if (status == 0) return "";
			if (status == 1) return "";
			if (status == 2) return "";
			if (status == 3) return "Lastad";
			if (status == 4) return "Lossad";
			return "";
		}
	}
}
