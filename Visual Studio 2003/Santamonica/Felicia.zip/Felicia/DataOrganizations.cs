using System;

namespace Navipro.SantaMonica.Felicia
{
	/// <summary>
	/// Summary description for DataOrganizations.
	/// </summary>
	public class DataOrganizations
	{
		public DataOrganizations()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
